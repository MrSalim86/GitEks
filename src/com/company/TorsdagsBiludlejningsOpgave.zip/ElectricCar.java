package com.company;

public class ElectricCar extends ACar{

    private int  batteryCapacity;
    private int  maxRange;

    public ElectricCar(String RegistrationNumber, String Make, String Model, int NumberOfDoors, int batteryCapacity, int maxRange) {
        super(RegistrationNumber, Make, Model, NumberOfDoors);
        this.batteryCapacity = batteryCapacity; // hvor meget den kan have i watt.
        this.maxRange = maxRange; // det er km længe for hvornår den skal lade op igen.
    }

    public int getBatteryCapacityKWh() {
        int wattPrKm = batteryCapacity / maxRange;
        int result = (int) (wattPrKm / 91.25 / 100);
        return result;                                    //returns the battery capacity in kilowatt hours
    }

     public int getMaxRangeKm() {

        return maxRange;                                  // returns the maximum range in kilometres.

    }

    public int getWhPrKm() {
        int wattPrKm = batteryCapacity / maxRange;

        return wattPrKm;                                  // returns the power consumption in watt hours per driven kilometre.
    }

    @Override
    public int getRegistrationFee() {
        return 0;
    }

    @Override
    public String toString() {
        return "\nElectricCar {" + "batteryCapacity=" + batteryCapacity + " maxRange:=" + maxRange + "} " + super.toString();
    }
}
