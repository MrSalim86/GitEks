package com.company;

public class GasolineCar extends AFuelCar {

    public GasolineCar(String RegistrationNumber, String Make, String Model, int NumberOfDoors, int kmPrLitre) {
        super(RegistrationNumber, Make, Model, NumberOfDoors, kmPrLitre);
    }

    @Override
    public String getFuelType() {
        return "FuelType Gasoline";
    }

    @Override
    public int getRegistrationFee() {
        return getDefaultRegistrationFee();
    }

    @Override
    public String toString() {
        return "\n"+ getFuelType() + " " + super.toString();
    }
}
