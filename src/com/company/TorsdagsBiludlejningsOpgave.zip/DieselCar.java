package com.company;

public class DieselCar extends AFuelCar {
public boolean hasParticleFilter;
    public DieselCar(String RegistrationNumber, String Make, String Model, int NumberOfDoors, int kmPrLitre, boolean hasParticleFilter) {
        super(RegistrationNumber, Make, Model, NumberOfDoors, kmPrLitre);
        this.hasParticleFilter = hasParticleFilter;
    }

    @Override
    public String getFuelType() {
        return "FuelType Diesel";
    }

    @Override
    public int getRegistrationFee() {
        int DefaultRegistrationFee = getDefaultRegistrationFee();

        int total = 0;

        if (this.kmPrLitre() <= 50 && this.kmPrLitre() >= 20) {
            total = 130 + DefaultRegistrationFee;
        }
        if (this.kmPrLitre() <= 20 && this.kmPrLitre() >= 15) {
            total = 1390 + DefaultRegistrationFee;
        }
        if (this.kmPrLitre() <= 15 && this.kmPrLitre() >= 10) {
            total = 1850 + DefaultRegistrationFee;
        }
        if (this.kmPrLitre() <= 5) {
            total = 2770 + DefaultRegistrationFee;
        }

        if (hasParticleFilter == false){
            total += 1000;

        }
        return total;

    }


    public boolean hasParticleFilter() {
        if (hasParticleFilter == false) {
        }
        return hasParticleFilter;
    }

    @Override
    public String toString() {
        return "\n"+ getFuelType() + " " + super.toString() + " hasParticleFilter " + hasParticleFilter;
    }
}

